###############################################
# 라이브러리
import requests
import csv
from urllib.request import urlopen
from bs4 import BeautifulSoup as bs
from urllib.parse import quote_plus # url에서 특수문자 한글 변환
import codecs
import time
import re
import random
############################################### 




###############################################
#searchName = input("검색어를 입력하세요: ")
#searchPageNumber = int(input("검색 페이지 숫자를 입력하세요: "))

# 구글학술 스크래핑 함수
def googleScraping(searchName, searchPageNumber):
    searchResult = []
    for num in range(searchPageNumber):
        # URL 및 요청
        startPageNumber = num*10
        url = f"https://scholar.google.co.kr/scholar?start={startPageNumber}&q={searchName}&hl=ko&as_sdt=0,5"   # start번호를 10씩 늘려가면 됨
        html = requests.get(url)

        # HTTP 상태 코드 확인
        if html.status_code == 200:
            for i in range(startPageNumber, startPageNumber+10):
                htmlcode = html.text
                # BeautifulSoup 객체 생성
                soup = bs(htmlcode, 'html.parser')

                individualPageInfo = []
                idvPageSource = soup.find("div", class_="gs_r gs_or gs_scl", attrs={"data-rp": f"{i}"})
                if idvPageSource:
                    # <h3> 태그 내의 <a> 태그 데이터 추출 - pageTitle, pageLink
                    data = idvPageSource.find("h3", class_="gs_rt")
                    link = data.find('a')
                    if link:
                        pageTitle = link.text
                        pageLink = link.get('href')
                        # print(pageTitle)
                        # print(pageLink)
                        individualPageInfo.append(pageTitle)
                        individualPageInfo.append(pageLink)

                    # 정규화식을 사용한 저널의 이름 추출
                    pattern = re.compile(r'-\s(.*?)(?=,)')
                    data2 = idvPageSource.find("div", class_="gs_a")
                    match = pattern.search(data2.text)
                    if match:
                        journalName = match.group(1).strip()
                        
                        # 저널의 이름에서 ... 생략표시 제거 
                        try:
                            checkJournalName = list(journalName)
                            for char in checkJournalName:
                                if char == '\xa0' :
                                    indexOfSpace = checkJournalName.index(char)
                                    checkJournalName = checkJournalName[:indexOfSpace]
                                else:
                                    char = char 
                            journalName = ''.join(checkJournalName)
                        except ValueError:
                            pass
                        # 저널의 이름에서 The 제거 
                        pattern2 = re.compile(r'\bThe\b', re.IGNORECASE)
                        journalName = pattern2.sub('', journalName).strip()

                        # 저널의 이름에서 & 제거
                        pattern3 = re.compile(r"&")
                        journalName = pattern3.sub('', journalName).strip()
                        # print(journalName)
                        individualPageInfo.append(journalName)
                else:
                    print("페이지를 찾지 못했습니다.")
                print(individualPageInfo)
                searchResult.append(individualPageInfo)
                print("#"*10 + f"individual page:{i+1}"+"#"*10)
                

                
            
        else:
            print("요청이 실패했습니다.")
            print(html.status_code)
        randomFloat = random.random() * 10
        time.sleep(randomFloat)


    f = codecs.open(f'{searchName}.csv', 'w', encoding='utf-8-sig')
    csvWriter = csv.writer(f)
    csvWriter.writerow(['제목', '링크', '저널'])

    for data in searchResult:
        csvWriter.writerow(data)

    f.close()
#################################################