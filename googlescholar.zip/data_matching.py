#################################################################
# 라이브러리 설치
import pandas as pd
import re
#################################################################





#################################################################
# impact factor 데이터 매칭 함수선언 
def dataMatching(impactPath, scrapingPath, scrapingWord, savePath):

    #################################################################
    # 데이터 불러오기
    # impact factor 데이터 파일 불러오기
    # path = r"C:\AI_lecture\crawling_personal_project\2022_JCR_임시판_230811.xlsx"
    impactFactorData = pd.read_excel(impactPath)


    # 스크래핑 데이터 불러오기
    # scrapingPath = r"C:\AI_lecture\crawling_personal_project\alzheimer's disease.csv"
    scrapingData = pd.read_csv(scrapingPath)
    ##################################################################





    ##################################################################
    # 데이터 매칭

    # '제목' 열의 각 항목들을 data1의 'title'에서 검색하여 매칭
    for index, row in scrapingData.iterrows():
        if isinstance(row['저널'], str):  # '저널' 값이 문자열인지 확인
            제목 = row['저널'].lower()
            best_match = None
            best_match_factor = None
            
            for _, df_row in impactFactorData.iterrows():
                title = df_row['TITLE'].lower()
                
                # '제목'이 'title'에 포함되거나 'title'이 '제목'에 포함되는 경우 매칭
                if re.search(re.escape(제목), title): # or re.search(re.escape(title), 제목):
                    best_match = df_row['TITLE']
                    best_match_factor = df_row['IMPACT_FACTOR']
                    break
            
            if best_match:
                scrapingData.at[index, 'TITLE'] = best_match
                scrapingData.at[index, 'IMPACT_FACTOR'] = best_match_factor


    # Excel 파일로 저장
    scrapingData.to_excel(f"{savePath}\{scrapingWord}_result.xlsx", index=False)
    ###################################################################


