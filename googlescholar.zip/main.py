##################################################
# 구글 학술 크롤링 및 impact factor별로 분류하기
# 2024-05-11 이상휘
##################################################

##################################################
# 기본 라이브러리 설치 
import sys
from PyQt5.QtWidgets import *
from PyQt5 import uic
from PyQt5.QtCore import *
from random import *
from scraping_google import googleScraping
from data_matching import dataMatching
##################################################



##################################################
# ui 파일 변수 저장 
mainPage = uic.loadUiType("ui/main.ui")[0]
searchPage = uic.loadUiType("ui/google_search.ui")[0]
##################################################




##################################################
# 첫번째 메인 페이지
# 클래스 지정
class MyWindow(QMainWindow, mainPage):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.btn_file.clicked.connect(self.btn_choosefile_clicked)
        self.btn_next.clicked.connect(self.btn_next_clicked)

        self.fileName = ""

    def getFileName(self):
        return self.fileName

    # impact factor 파일 불러오기 버튼 
    def btn_choosefile_clicked(self):
        # print("button was clicked")
        fname=QFileDialog.getOpenFileName(self)        
        self.fileName = fname[0]
        print(self.fileName)
        self.lb_filename.setText(self.fileName)


    # 다음 단계 버튼
    def btn_next_clicked(self):
        if self.fileName == "":
            QMessageBox.about(self, "에러", "파일을 선택하지 않았습니다.")
            return
        self.hide()
        self.main = MyWindow2(self)
        self.main.show()



##################################################






##################################################
# 두번째 구글 학술 검색 페이지
# 클래스 지정
class MyWindow2(QMainWindow, searchPage):
    def __init__(self, mainWindow):
        super().__init__()
        self.setupUi(self)
        self.mainWindow = mainWindow
        self.btn_before.clicked.connect(self.btn_before_clicked)
        self.btn_search.clicked.connect(self.btn_search_clicked)
        self.btn_findfolder.clicked.connect(self.btn_findfolder_clicked)

        self.folderName = ""
        self.searchWord = ""
        self.searchPageNum = ""


    # 이전단계 버튼
    def btn_before_clicked(self):
        self.hide()
        self.main = MyWindow()
        self.main.show()

    # 구글 검색 버튼
    def btn_search_clicked(self):
        self.searchWord = self.le_searchword.text()
        self.searchPageNum = self.le_searchpagenum.text()
        
        # 예외처리
        if self.folderName == "":
            QMessageBox.about(self, "에러", "폴더를 선택하지 않았습니다.")
            return
        elif self.searchWord == "":
            QMessageBox.about(self, "에러", "검색어를 입력하지 않았습니다.")
            return
        elif self.searchPageNum == "":
            QMessageBox.about(self, "에러", "페이지 숫자를 입력하지 않았습니다.")
            return
        
        # try:
        self.searchPageNum = int(self.searchPageNum)    
        # print(self.searchWord)
        # print(self.searchPageNum)
        # print(type(self.searchPageNum))
        try:
            self.impactFactorFile = self.mainWindow.getFileName()
            googleScraping(self.searchWord, self.searchPageNum)
            dataMatching(self.impactFactorFile, f'{self.searchWord}.csv', self.searchWord, self.folderName)
            QMessageBox.about(self, "성공", "파일이 저장되었습니다.")

        except Exception as e:
            QMessageBox.about(self, "에러", f"오류 발생: {e}")
            return


    # 저장위치 폴더찾기 버튼
    def btn_findfolder_clicked(self):
        self.folderName = QFileDialog.getExistingDirectory(self, "폴더찾기","")
        print(self.folderName)
        self.lb_foldername.setText(self.folderName)



##################################################







##################################################
# 파일 실행
app = QApplication(sys.argv)
window = MyWindow()
window.show()
app.exec_()

##################################################

